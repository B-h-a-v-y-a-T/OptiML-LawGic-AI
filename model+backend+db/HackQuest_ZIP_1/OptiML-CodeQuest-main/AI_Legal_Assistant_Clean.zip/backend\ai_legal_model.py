# Convenience re-export so tools/scripts at project root can import the model directly
from app.ml.ai_legal_model import AiLegalAssistantModel  # noqa: F401
